import Foundation

// MARK: - Welcome

struct Welcome: Codable {
    let cards: [Card]
}

// MARK: - Card

struct Card: Codable {
    let name: String?
    let manaCost: String?
    let cmc: Int?
    let type: String?
    let subtypes: [String]?
    let flavor: String?
}

func getData(urlRequest: String) {
    let urlRequest = URL(string: urlRequest)
    let configuration = URLSessionConfiguration.default
    configuration.allowsCellularAccess = true
    guard let url = urlRequest else { return }
    
    URLSession.shared.dataTask(with: url) { (data, response, error) in
        DispatchQueue.main.async {
            if let error = error {
                print("error: \(error.localizedDescription)")
            }
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else { return }
            print("\(response.statusCode)")

            guard let data = data else { return }
            do {
                let dataAsString = try JSONDecoder().decode(Welcome.self, from: data)
                print("""
Card:
name:\(dataAsString.cards.first?.name ?? "")
manaCost:\(dataAsString.cards.first?.manaCost ?? "")
cmc: \(dataAsString.cards.first?.cmc ?? 0)
type: \(dataAsString.cards.first?.type ?? "")
subtypes: \(dataAsString.cards.first?.subtypes?.first ?? "no")
flavor: \(dataAsString.cards.first?.flavor ?? "")
""")
            } catch {
                print(error)
            }
        }
    }.resume()
}

let magic = "https://api.magicthegathering.io/v1/cards?name=%22Opt%22"
let magic1 = "https://api.magicthegathering.io/v1/cards?name=black%20lotus"

getData(urlRequest: magic)
